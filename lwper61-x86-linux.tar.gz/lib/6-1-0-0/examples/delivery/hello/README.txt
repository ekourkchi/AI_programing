;; -*- Mode: Text; rcs-header: "$Header: /hope/lwhope1-cam/hope.0/compound/23/LISPexamples/RCS/delivery:hello:README.txt,v 1.2.1.1 2011/08/24 13:26:19 davef Exp $" -*-

;; Copyright (c) 1987--2012 LispWorks Ltd. All rights reserved.

Hello
-----

Minimal example of an interactive delivered application.

Use deliver.lisp as the delivery script (see ../README.txt)

Files:
   hello.lisp
    The example application code. It just displays a message. 

   deliver.lisp 
    The delivery script. 
