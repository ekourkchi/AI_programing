;; -*- Mode: Text; rcs-header: "$Header: /hope/lwhope1-cam/hope.0/compound/23/LISPexamples/RCS/delivery:debugger-hook:README.txt,v 1.3.1.1 2011/08/24 13:26:18 davef Exp $" -*-

;; Copyright (c) 1987--2012 LispWorks Ltd. All rights reserved.

Debugger-hook
-------------

An example of catching errors using *DEBUGGER-HOOK* in 
a delivered application. 

See comments at the top of application-with-errors.lisp for details.

Deliver by using deliver.lisp as delivery script (see ../README.txt). 

Files:

   application-with-errors.lisp
      The example application code. 
   
   deliver.lisp 
      The delivery script. 
