/*
** $Header: /hope/lwhope1-cam/hope.0/compound/56/LISPcorba-doc-hello-world/RCS/cplusplus:orb.h,v 1.1.12.1 2011/08/24 13:26:00 davef Exp $
**
** Copyright (c) 1987--2012 LispWorks Ltd. All rights reserved.
*/


#include <OB/CORBA.h>
