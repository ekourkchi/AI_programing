This directory can contain AFM files for fonts used by CAPI Postscript printing.
