;; -*- Mode: Text; rcs-header: "$Header: /hope/lwhope1-cam/hope.0/compound/23/LISPexamples/RCS/delivery:othello:README.txt,v 1.2.1.1 2011/08/24 13:26:18 davef Exp $" -*-

;; Copyright (c) 1987--2012 LispWorks Ltd. All rights reserved.

Othello
-------

An example of delivering an interactive application. 

In particular this demonstrates how to create an application bundle on
Mac OS X.

Use deliver.lisp as the delivery cript (see ../README.txt). 

Creates a delivered application that plays the Othello game. 

The actual application is part of the CAPI application examples, 
../../capi/applications/othello.lisp

Files:
  deliver.lisp 
     The delivery script. 
