drop table VEHICLE;
drop table PERSON;
drop table COMPANY;
